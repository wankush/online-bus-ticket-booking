﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Drawing;
using System.Net.Mail;
namespace WebApplication1.agencys
{
    public partial class deteils : System.Web.UI.Page
    {
        string perid = "";
        int id = 0;
        string name = "";
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie reqCookies = Request.Cookies["AperInfo"];
            if (reqCookies != null)
            {
                perid = reqCookies["loginID"].ToString();
             }
            else
            {
                Response.Redirect("~/LOGIN.aspx");
            }
            getid();
            Panel3.Visible = false;
            Panel4.Visible = false;
            btnadd.Visible = false;
            btnupdate.Visible = false;
            GridView1.Visible = true;
            Label26.Text = "Agency Dashboard," + " " + "/" + name.ToString();
        }

        protected void TextBox9_TextChanged(object sender, EventArgs e)
        {

        }
        public void getid()
        {
            //get personal id
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select id,name from personalinfo where regid='"+perid+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    id = int.Parse(dr[0].ToString());
                    name = dr[1].ToString();
                    Label21.Text = Convert.ToString(id);
                }
                con.Close();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //update button
            Panel3.Visible = true;
            Panel4.Visible = true;
            btnadd.Visible = false;
            btnupdate.Visible = true;
            GridView1.Visible = false;
            
        }

        protected void Button3_Click(object sender, EventArgs e)
        { 
            //add button
            Panel3.Visible = true;
            Panel4.Visible = false;
            btnadd.Visible = true;
            btnupdate.Visible = false;
            GridView1.Visible = false;
            rstart.Text = "";
            rend.Text = "";
            droppoint1.Text = "";
            droppoint2.Text = "";
            droppoint3.Text = "";
            pickuppoint1.Text = "";
            pickuppoint2.Text = "";
            pickuppoint3.Text = "";
            fare.Text = "";
            mno.Text = "";
            busno.Text = "";

        }

        protected void Button1_Click(object sender, EventArgs e)
        { 
            // view all bus
            Panel3.Visible = false;
            Panel4.Visible = false;
            btnadd.Visible = false;
            btnupdate.Visible = false;
            GridView1.Visible = true;
           
        }

        public void getagencyname()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select agname from personalinfo where regid='" + perid + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    aname.Text =  dr[0].ToString() ;
                }
                con.Close();
            }
        }
        protected void btnadd_Click(object sender, EventArgs e)
        {
            //ADD NEW BUS 
            
            getagencyname();
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("agencyregs", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@aname",aname.Text);
                cmd.Parameters.AddWithValue("@ac", acnonac.Text);
                cmd.Parameters.AddWithValue("@seat", 30);
                cmd.Parameters.AddWithValue("@fare", fare.Text);
                cmd.Parameters.AddWithValue("@rstart", rstart.Text);
                cmd.Parameters.AddWithValue("@rend", rend.Text);
                cmd.Parameters.AddWithValue("@ppoint1", pickuppoint1.Text);
                cmd.Parameters.AddWithValue("@ppoint2", pickuppoint2.Text);
                cmd.Parameters.AddWithValue("@ppoint3", pickuppoint3.Text);
                cmd.Parameters.AddWithValue("@dpoint1", droppoint1.Text);
                cmd.Parameters.AddWithValue("@dpoint2", droppoint2.Text);
                cmd.Parameters.AddWithValue("@dpoint3", droppoint3.Text);
                cmd.Parameters.AddWithValue("@stime", stime.Text);
                cmd.Parameters.AddWithValue("@etime", tend.Text);
                cmd.Parameters.AddWithValue("@mno", mno.Text);
                cmd.Parameters.AddWithValue("@busno", busno.Text);
                cmd.Parameters.AddWithValue("@pid",id);
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Register Sucessfully...!');", true);
                rstart.Text = "";
                rend.Text = "";
                droppoint1.Text = "";
                droppoint2.Text = "";
                droppoint3.Text = "";
                pickuppoint1.Text = "";
                pickuppoint2.Text = "";
                pickuppoint3.Text = "";
                fare.Text = "";
                mno.Text = "";
                busno.Text = "";

            }

        }

        protected void search_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "SELECT * FROM agencyreg  where id='"+int.Parse(TextBox16.Text)+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    aname.Text = dr[1].ToString();
                    acnonac.Text = dr[2].ToString();
                    fare.Text = dr[4].ToString();
                    rstart.Text = dr[5].ToString();
                    rend.Text = dr[6].ToString();
                    pickuppoint1.Text = dr[7].ToString();
                    pickuppoint2.Text = dr[8].ToString();
                    pickuppoint3.Text = dr[9].ToString();
                    droppoint1.Text = dr[10].ToString();
                    droppoint2.Text = dr[11].ToString();
                    droppoint3.Text = dr[12].ToString();
                    stime.Text = dr[13].ToString();
                    tend.Text = dr[14].ToString();
                    busno.Text = dr[16].ToString();
                    mno.Text = dr[15].ToString();
                }
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            //update 
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "update agencyreg set aname='"+aname.Text+"',ac='"+acnonac.Text+"',fare='"+fare.Text+"',rstart='"+rstart.Text+"' ,rend='"+rend.Text+"',ppoint1='" + pickuppoint1.Text + "',ppoint2='" + pickuppoint2.Text + "',ppoint3='" + pickuppoint3.Text+"',dpoint1='" + droppoint1.Text + "',dpoint2='" + droppoint2.Text + "',dpoint3='" + droppoint3.Text+"',stime='"+stime.Text+"',etime='"+tend.Text+"',mno='"+mno.Text+"',busno='"+busno.Text+"' where id='"+TextBox16.Text+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                 
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Register Sucessfully...!');", true);

            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                int i = 0;
                con.Open();
                string str = "select  totalseat from bookticket where bdate='" + bookingdate.Text+"' AND busid='"+int.Parse(Busid.Text)+"'";  
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                { 
                    while(dr.Read())
                    { 
                     i  = i+ int.Parse(dr[0].ToString());
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid Date and Bus ID');", true);
                }
                Label25.Text = Convert.ToString(i);
                con.Close();
             }
        }

        protected void deltebus_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "delete from agencyreg  where id='" + int.Parse(TextBox17.Text) + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Delete bus Sucessful!');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid bus ID!');", true);
                }
                con.Close();
            }
        }
    }
}