﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
namespace WebApplication1.agencys
{
    public partial class Registerag : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        int aid;
        string loginid;
        protected void Page_Load(object sender, EventArgs e)
        {
            getaid();
        }

        protected void travalinfo_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
        }

        protected void personalinfo_Click(object sender, EventArgs e)
        {
            insertagency();
            insertpersonalinfo();
           // addseat();
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Register Sucessfully...!');", true);
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            TextBox9.Text = "";
            TextBox10.Text = "";
            TextBox11.Text = "";
            TextBox12.Text = "";
            TextBox13.Text = "";
            TextBox14.Text = "";
            TextBox15.Text = "";
            TextBox16.Text = "";
            TextBox17.Text = "";
            TextBox18.Text = "";
            TextBox20.Text = "";
            TextBox19.Text = "";
             
        }
        public void insertagency()
        {
            string acn = "";
            if (RadioButton1.Checked == true)
            {
                acn = "AC";
            }
            if (RadioButton2.Checked == true)
            {
                acn = "NON AC";
            }
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
              
                SqlCommand cmd = new SqlCommand("agencyregs", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@aname", TextBox1.Text);
                cmd.Parameters.AddWithValue("@ac", acn.ToString());
                cmd.Parameters.AddWithValue("@seat", 30);
                cmd.Parameters.AddWithValue("@fare", TextBox2.Text);
                cmd.Parameters.AddWithValue("@rstart", TextBox3.Text);
                cmd.Parameters.AddWithValue("@rend", TextBox4.Text);
                cmd.Parameters.AddWithValue("@ppoint1", TextBox5.Text);
                cmd.Parameters.AddWithValue("@ppoint2", TextBox6.Text);
                cmd.Parameters.AddWithValue("@ppoint3", TextBox7.Text);
                cmd.Parameters.AddWithValue("@dpoint1", TextBox10.Text);
                cmd.Parameters.AddWithValue("@dpoint2", TextBox9.Text);
                cmd.Parameters.AddWithValue("@dpoint3", TextBox8.Text);
                cmd.Parameters.AddWithValue("@stime", TextBox11.Text);
                cmd.Parameters.AddWithValue("@etime", TextBox12.Text);
                cmd.Parameters.AddWithValue("@mno", TextBox14.Text);
                cmd.Parameters.AddWithValue("@busno", TextBox13.Text);
                cmd.Parameters.AddWithValue("@pid", aid.ToString());
                cmd.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Register Sucessfully...!');", true);
            }
        }
        public void getaid()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select top 1 id from  personalinfo order by id desc ";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read()) 
                {
                    aid = int.Parse(dr[0].ToString());
                    aid = aid + 1;
                }
                con.Close();
            }
        }
        public void insertpersonalinfo()
        {
            Random r = new Random();
            int genRand = r.Next(0000,9999);
              loginid = "TA" + Convert.ToString(genRand); 
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("spinsertpinfo", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", TextBox15.Text);
                cmd.Parameters.AddWithValue("@mno", TextBox16.Text);
                cmd.Parameters.AddWithValue("@email", TextBox17.Text);
                cmd.Parameters.AddWithValue("@address", TextBox18.Text);
                cmd.Parameters.AddWithValue("@agname ", TextBox1.Text  );
                cmd.Parameters.AddWithValue("@regid",loginid.ToString());
                cmd.Parameters.AddWithValue("@pass", TextBox20.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                
            }
            sendemail();
        }
        public void sendemail()
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(TextBox17.Text);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Registration mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, "+TextBox15.Text+ " <br /><br /> Welcome in AR-Booking <br /> Your login ID is :" + loginid+ "<br /> password:" + TextBox20.Text+ " <br /><br /> ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);
               
            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }
              
            }
        }

        public void addseat()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                for(int i = 1; i <= 30; i++) {
                string str = "insert into seatavaiable values('"+aid+"','"+i+"','A')";
                SqlCommand cmd = new SqlCommand(str, con);
                
                cmd.ExecuteNonQuery();
                }
                con.Close();

            }
        }
    }
}