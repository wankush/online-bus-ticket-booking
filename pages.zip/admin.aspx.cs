﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Drawing;
namespace WebApplication1
{
    public partial class admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            GridView2.Visible = false;
            GridView3.Visible = false;
            GridView4.Visible = false;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            GridView2.Visible = true;
            GridView3.Visible = false;
            GridView4.Visible = false;
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            GridView2.Visible = false;
            GridView3.Visible = true;
            GridView4.Visible = false;
        }

        protected void BTNUSERINFO_Click(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            GridView2.Visible = false;
            GridView3.Visible = false;
            GridView4.Visible = true;
        }
        string link = "";
        protected void sendmailinl_Click(object sender, EventArgs e)
        {
            
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select * from registerlink";
                SqlCommand cmd = new SqlCommand(str,con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    link = dr[0].ToString();
                    sendmail();
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('mail send sucessfull');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('invalid mail ID!');", true);
                }
                con.Close();
            }
        }
        public void sendmail()
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(TextBox1.Text);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Invitation  mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, Agent <br /><br />  Welcome in AR-Booking <br/> think you intresting in AR BooKing we Accept your request <br/> we send registration link below please register and make a family with AR-Booking <br/>"+link.ToString()+"<br/>    <br /><br /> ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }

            }
        }

    }
}