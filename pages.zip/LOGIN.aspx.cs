﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Drawing;
namespace WebApplication1
{
    public partial class LOGIN : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        int aid;
        string loginid;

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Panel2.Visible = true;
            Panel4.Visible = false;
        }

        protected void Button2_Click(object sender, EventArgs e)
        { 
            //registration
            Random r = new Random();
            int genRand = r.Next(0000, 9999);
            loginid = "UA" + Convert.ToString(genRand);
            string gender = "";
            if (RadioButton1.Checked == true)
            {
                gender = "Male";
            }
            if (RadioButton2.Checked == true)
            {
                gender = "Female";
            }
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("spuserinfo", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", TextBox3.Text);
                cmd.Parameters.AddWithValue("@gender", gender.ToString());
                cmd.Parameters.AddWithValue("@email", TextBox4.Text);
                cmd.Parameters.AddWithValue("@mno", TextBox6.Text);
                cmd.Parameters.AddWithValue("@uid", loginid.ToString());

                cmd.Parameters.AddWithValue("@pass", TextBox8.Text);
                cmd.ExecuteNonQuery();
                sendmail();
                con.Close();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Register Sucessfully...!');", true);
                TextBox8.Text = "";
                TextBox7.Text = "";
                TextBox6.Text = "";
                TextBox5.Text = "";
                TextBox4.Text = "";
                TextBox3.Text = "";
                Panel3.Visible = false;
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        { 

            //mail varification code sending
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                Random r = new Random();
                  vcode = r.Next(0000, 9999);
                string str = "insert into emailvarify values( '"+vcode+"','false','"+TextBox4.Text+"')";
                SqlCommand cmd = new SqlCommand(str, con);
                int i =cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    sendmailcode();
                    Label10.Visible = true;
                    variycode.Visible = true;
                    TextBox5.Visible = true;
                }
                con.Close();

            }
        }
        int vcode;
        public void sendmailcode()
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(TextBox4.Text);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Varification code mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, " + TextBox3.Text + " <br /><br /> Your Varification code is :"+vcode+"  <br /><br /> ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }

            }
        }
        public void sendmail()
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(TextBox4.Text);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Registration  mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, " + TextBox3.Text + " <br /><br />  Welcome in AR-Booking <br/>  your login id:" + loginid + " <br/> Password:"+TextBox8.Text+"  <br /><br /> ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }

            }
        }
        protected void variycode_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                Random r = new Random();
                vcode = r.Next(0000, 9999);
                string str = "update emailvarify set status='ture' where code='"+TextBox5.Text+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                     
                    Label10.Visible = false;
                    variycode.Visible = false;
                    TextBox5.Visible = false;
                    Button4.BackColor = Color.Green;

                }
                con.Close();

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //login button 
            string lid = TextBox1.Text;
            string lgid = lid.Substring(0, 2);
            if (lgid == "UA")
            {
                using (SqlConnection con = new SqlConnection(strcon))
                {
                    string str1 = "select * from userinfo where uid='"+TextBox1.Text+"' AND pass='"+TextBox2.Text+"'";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(str1, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        HttpCookie userInfo = new HttpCookie("userInfo");
                        userInfo["loginID"] = TextBox1.Text;

                        Response.Cookies.Add(userInfo);
                        Response.Redirect("~/showbuss.aspx");
                    }
                    else { ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid Login ID and Password...!');", true); }
                    con.Close();
                }
            }
            else if (lgid == "TA")
            {
                using (SqlConnection con = new SqlConnection(strcon))
                {
                    con.Open();
                    string str2 = "select * from personalinfo where regid='"+TextBox1.Text+"' AND pass='"+TextBox2.Text+"'";
                    SqlCommand cmd = new SqlCommand(str2, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        HttpCookie userInfo = new HttpCookie("AperInfo");
                        userInfo["loginID"] = TextBox1.Text;

                        Response.Cookies.Add(userInfo);
                        Response.Redirect("~/agencys/deteils.aspx");
                    }
                    else { ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid Login ID and Password...!');", true); }

                    con.Close();
                }
            }
            else if (lgid == "AA")
            {
                string str3 = "select * from adminlogin where id='"+TextBox1.Text+"' AND pass='"+TextBox2.Text+"'";
                using (SqlConnection con = new SqlConnection(strcon))
                {
                    con.Open();
                  
                    SqlCommand cmd = new SqlCommand(str3, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        HttpCookie userInfo = new HttpCookie("userInfo");
                        userInfo["loginID"] = TextBox1.Text;

                        Response.Cookies.Add(userInfo);
                        Response.Redirect("~/admin.aspx");
                    }
                    else { ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid Login ID and Password...!');", true); }

                    con.Close();
                }
            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Panel2.Visible = false;
            Panel4.Visible = true;
        }

        protected void forgotpass_Click(object sender, EventArgs e)
        {
            string getid = TextBox11.Text;
            string lgid = getid.Substring(0, 2);
            if (lgid == "UA")
            {
                
                using (SqlConnection con = new SqlConnection(strcon))
                {
                    string str1 = "update userinfo set pass='" + TextBox10.Text + "' where uid='" + TextBox11.Text + "' ";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(str1, con);
                    int i = cmd.ExecuteNonQuery();
                    if (i == 1)
                    {
                        getmailuserinfo();
                        userpasssendmail();
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Password Reset Sucessful!');", true);
                        Panel4.Visible = false;
                    }
                    else { ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid Email ID...!');", true); }
                    con.Close();
                }
            }
            else if (lgid == "TA")
            {
                getagmail();
                using (SqlConnection con = new SqlConnection(strcon))
                {
                    con.Open();
                    string str2 = "update personalinfo set pass='"+TextBox10.Text+"' where regid='"+TextBox11.Text+"' ";
                    SqlCommand cmd = new SqlCommand(str2, con);
                    int i = cmd.ExecuteNonQuery();
                    if (i ==1)
                    {
                        agcypasssendmail();
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Password Reset Sucessful!');", true);
                        Panel4.Visible = false;
                    }
                     

                    con.Close();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid Login ID and Password...!');", true);
            }
        }
        public void userpasssendmail()
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(usermail);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Password Reset  mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, user your password as been reset  your new <br /> password:"+TextBox10.Text+"   <br /><br /> ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }

            }
        }
        string usermail = "";
        string agmail = "";
        public void agcypasssendmail()
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(agmail);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Password Reset  mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, user your password as been reset  your new <br /> password:" + TextBox10.Text + "   <br /><br /> ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }

            }
        }

        public void getmailuserinfo()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select email from userinfo where uid='"+TextBox11.Text+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    usermail = dr[0].ToString();
                }
                con.Close();
            }
        }
        public void getagmail()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select email from personalinfo where regid='"+TextBox11.Text+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    agmail = dr[0].ToString();
                }
                con.Close();
            }
        }
    }
}