﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Drawing;
using System.Net.Mail;
namespace WebApplication1
{
    public partial class checkticket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ToString();
        string userid = "";
        protected void Button1_Click(object sender, EventArgs e)
        {
            // search ticket 
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select pname,rstart,rend,numseat,total,tid,jdate,userid  from bookticket where pnr='" + TextBox1.Text+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    name.Text = dr[0].ToString();
                    agencyname.Text = dr[5].ToString();
                    rstart.Text = dr[1].ToString();
                    rend.Text = dr[2].ToString();
                    seat.Text = dr[3].ToString();
                    total.Text = dr[4].ToString();
                    jdate.Text = dr[6].ToString();
                    userid = dr[7].ToString();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Invalid PNR!');", true);
                }
                con.Close();
            }
            Panel4.Visible = true;
            Panel3.Visible = true;
            Label9.Text = TextBox1.Text;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            //cancel ticket 
            using (SqlConnection con = new SqlConnection(strcon))
            {
                string str = "delete from bookticket where pnr='"+TextBox1.Text+"'";
                SqlCommand cmd = new SqlCommand(str, con);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Ticket Cancel Sucessfully...!');", true);
                    sendmail();
                    deletebookticket();
                }
                 
            }
        }
        public void sendmail()
        {
            string mailid = "";
            string name = "";
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select name,email from userinfo where uid='" + userid + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    mailid = dr[1].ToString();
                    name = dr[0].ToString();
                }
                con.Close();
            }
                System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(mailid);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Cancellation  mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, " + name.ToString() + " <br /><br />  Welcome in AR-Booking <br/>  your Ticket as been Canceled <br /> Booking Deteils <br />PNR: #"+TextBox1.Text+" <br /> Route:"+rstart.Text+" to "+rend.Text+" <br /> Seats: "+seat.Text+" <br /> Total: "+total.Text+" <br /><br /> ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }

            }
        }
        
        public void deletebookticket()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "delete from seatavaiable where userid='"+userid+"' ";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }
}