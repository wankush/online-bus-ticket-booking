﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Drawing;
using System.Net.Mail;
using System.IO;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using iTextSharp.text;

namespace WebApplication1
{
    public partial class bookticket : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ToString();
        int aid = 0;
        int fare = 0;
        static int count = 0;
        string date = "";
        string userid = "";
        string busno = "";
        string mno = "";
        static Dictionary<int, string> ob =
                      new Dictionary<int, string>();
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie reqCookies = Request.Cookies["userInfo"];
            if (reqCookies != null)
            {
                userid = reqCookies["loginID"].ToString();
                aid = int.Parse(Request.QueryString["aid"]);
                date = Request.QueryString["date"].ToString();
                TextBox5.Text = date.ToString();
                nameuser();
                Label31.Text = "Welcome, " + " " + username.ToString();
            }
            else
            {
                Response.Redirect("~/LOGIN.aspx");
            }
            // Label14.Text = Convert.ToString(0);

            TextBox5.Text = date.ToString();
            callmethodseat();
            getdata();
            pickpoint();
            droppoint();

        }
        string username = "";

        public void callmethodseat()
        {
            seatavaiable1();
            seatavaiable2();
            seatavaiable3();
            seatavaiable4();
            seatavaiable5();
            seatavaiable6();
            seatavaiable7();
            seatavaiable8();
            seatavaiable9();
            seatavaiable10();
            seatavaiable11();
            seatavaiable11();
            seatavaiable12();
            seatavaiable13();
            seatavaiable14();
            seatavaiable15();
            seatavaiable16();
            seatavaiable17();
            seatavaiable18();
            seatavaiable19();
            seatavaiable20();
            seatavaiable21();
            seatavaiable22();
            seatavaiable23();
            seatavaiable24();
            seatavaiable25();
            seatavaiable26();
            seatavaiable27();
            seatavaiable28();
            seatavaiable29();
            seatavaiable30();
        }
        public void getdata()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select aname,ac,fare,rstart, rend,stime,etime,mno,busno from agencyreg where id=" + aid + "";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Label7.Text = dr[0].ToString();
                    Label8.Text = dr[1].ToString();

                    Label9.Text = dr[3].ToString();
                    Label10.Text = dr[5].ToString();

                    Label11.Text = dr[4].ToString();
                    Label12.Text = dr[6].ToString();
                    busno = dr[8].ToString();
                    mno = dr[7].ToString();
                    fare = int.Parse(dr[2].ToString());
                }
                con.Close();
            }
        }
        public void seatavaiable1()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=1 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    string sta = "B";
                    if (status == sta)
                    {
                        //Button1.Style["background-color"] = "#db2853";
                        Button1.BackColor = System.Drawing.Color.Red;
                        Button1.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable2()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=2 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button2.BackColor = Color.Red;
                        Button2.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable3()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=3 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button3.BackColor = Color.Red;
                        Button3.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable4()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=4 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button4.BackColor = Color.Red;
                        Button4.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable5()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=5 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button5.BackColor = Color.Red;
                        Button5.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable6()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=6 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button6.BackColor = Color.Red;
                        Button6.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable7()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=7 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "' ";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button7.BackColor = Color.Red;
                        Button7.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable8()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=8 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button8.BackColor = Color.Red;
                        Button8.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable9()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=9 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button9.BackColor = Color.Red;
                        Button9.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable10()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=10 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button10.BackColor = Color.Red;
                        Button10.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable11()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=11 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button11.BackColor = Color.Red;
                        Button11.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable12()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=12 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button12.BackColor = Color.Red;
                        Button12.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable13()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=13 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button13.BackColor = Color.Red;
                        Button13.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable14()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=14 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button14.BackColor = Color.Red;
                        Button14.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable15()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=15 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button15.BackColor = Color.Red;
                        Button15.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable16()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=16 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button16.BackColor = Color.Red;
                        Button16.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable17()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=17 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button17.BackColor = Color.Red;
                        Button17.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable18()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=18 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button18.BackColor = Color.Red;
                        Button18.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable19()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=19 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button19.BackColor = Color.Red;
                        Button19.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable20()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=20 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button20.BackColor = Color.Red;
                        Button20.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable21()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=21 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button21.BackColor = Color.Red;
                        Button21.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable22()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=22 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button22.BackColor = Color.Red;
                        Button22.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable23()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=23 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button23.BackColor = Color.Red;
                        Button23.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable24()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=24 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button24.BackColor = Color.Red;
                        Button24.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable25()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=25 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button25.BackColor = Color.Red;
                        Button25.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable26()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=26 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button26.BackColor = Color.Red;
                        Button26.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable27()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=27 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button27.BackColor = Color.Red;
                        Button27.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable28()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=28 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button28.BackColor = Color.Red;
                        Button28.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable29()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=29 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button29.BackColor = Color.Red;
                        Button29.Enabled = false;
                    }
                }
            }
        }
        public void seatavaiable30()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select status from seatavaiable where seatno=30 AND aid=" + aid + " AND bdate='" + TextBox5.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string status = dr[0].ToString();
                    if (status == "B")
                    {
                        Button30.BackColor = Color.Red;
                        Button30.Enabled = false;
                    }
                }
            }
        }

        public void pickpoint()
        {
            DropDownList1.Items.Clear();
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                List<string> ob = new List<string>();
                string str = "select ppoint1,ppoint2,ppoint3 from  agencyreg where id=" + aid + "";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    DropDownList1.Items.Add(dr[0].ToString());
                    DropDownList1.Items.Add(dr[1].ToString());
                    DropDownList1.Items.Add(dr[2].ToString());
                }


            }
        }
        public void droppoint()
        {
            DropDownList2.Items.Clear();
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();

                string str = "select dpoint1,dpoint2,dpoint3 from  agencyreg where id=" + aid + "";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    DropDownList2.Items.Add(dr[0].ToString());
                    DropDownList2.Items.Add(dr[1].ToString());
                    DropDownList2.Items.Add(dr[2].ToString());
                }


            }
        }

        public void Button1_Click(object sender, EventArgs e)
        {

            int total = 0;
            if (Button1.BackColor != Color.Green)
            {
                ob.Add(1, "1,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button1.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button1.BackColor == Color.Green)
            {
                ob.Remove(1);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button1.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }


        }
        public void Button2_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button2.BackColor != Color.Green)
            {
                ob.Add(2, "2,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button2.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button2.BackColor == Color.Green)
            {
                ob.Remove(2);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button2.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }
        public void Button3_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button3.BackColor != Color.Green)
            {
                ob.Add(3, "3,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button3.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button3.BackColor == Color.Green)
            {
                ob.Remove(3);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button3.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button4.BackColor != Color.Green)
            {
                ob.Add(4, "4,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button4.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button4.BackColor == Color.Green)
            {
                ob.Remove(4);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button4.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);

                }
            }
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button5.BackColor != Color.Green)
            {
                ob.Add(5, "5,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button5.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button5.BackColor == Color.Green)
            {
                ob.Remove(5);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button5.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            int total = 0;

            // Label15.Text = Convert.ToString(count);

            Label15.Text = "";
            if (Button6.BackColor != Color.Green)
            {
                ob.Add(6, "6,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button6.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button6.BackColor == Color.Green)
            {
                ob.Remove(6);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button6.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }


        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button11.BackColor != Color.Green)
            {
                ob.Add(11, "11,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button11.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button11.BackColor == Color.Green)
            {
                ob.Remove(11);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button11.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button12_Click(object sender, EventArgs e)
        {

            int total = 0;
            if (Button12.BackColor != Color.Green)
            {
                ob.Add(12, "12,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button12.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button12.BackColor == Color.Green)
            {
                ob.Remove(12);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button12.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button10.BackColor != Color.Green)
            {
                ob.Add(10, "10,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button10.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button10.BackColor == Color.Green)
            {
                ob.Remove(10);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button10.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button9.BackColor != Color.Green)
            {
                ob.Add(9, "9,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button9.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button9.BackColor == Color.Green)
            {
                ob.Remove(9);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button9.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button7.BackColor != Color.Green)
            {
                ob.Add(7, "7,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button7.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button7.BackColor == Color.Green)
            {
                ob.Remove(7);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button7.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button8.BackColor != Color.Green)
            {
                ob.Add(8, "8,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button8.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button8.BackColor == Color.Green)
            {
                ob.Remove(8);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button8.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button13.BackColor != Color.Green)
            {
                ob.Add(13, "13,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button13.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button13.BackColor == Color.Green)
            {
                ob.Remove(13);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button13.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button14.BackColor != Color.Green)
            {
                ob.Add(14, "14,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button14.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button14.BackColor == Color.Green)
            {
                ob.Remove(14);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button14.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button15.BackColor != Color.Green)
            {
                ob.Add(15, "15,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button15.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button15.BackColor == Color.Green)
            {
                ob.Remove(15);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button15.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button16_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button16.BackColor != Color.Green)
            {
                ob.Add(16, "16,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button16.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button16.BackColor == Color.Green)
            {
                ob.Remove(16);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button16.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button19_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button19.BackColor != Color.Green)
            {
                ob.Add(19, "19,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button19.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button19.BackColor == Color.Green)
            {
                ob.Remove(19);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button19.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button20_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button20.BackColor != Color.Green)
            {
                ob.Add(20, "20,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button20.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button20.BackColor == Color.Green)
            {
                ob.Remove(20);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button20.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button18_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button18.BackColor != Color.Green)
            {
                ob.Add(18, "18,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button18.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button18.BackColor == Color.Green)
            {
                ob.Remove(18);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button18.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button21_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button21.BackColor != Color.Green)
            {
                ob.Add(21, "21,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button21.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button21.BackColor == Color.Green)
            {
                ob.Remove(21);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button21.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button24_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button24.BackColor != Color.Green)
            {
                ob.Add(24, "24,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button24.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button24.BackColor == Color.Green)
            {
                ob.Remove(24);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button24.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button23_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button23.BackColor != Color.Green)
            {
                ob.Add(23, "23,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button23.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button23.BackColor == Color.Green)
            {
                ob.Remove(23);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button23.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button22_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button22.BackColor != Color.Green)
            {
                ob.Add(22, "22,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button22.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button22.BackColor == Color.Green)
            {
                ob.Remove(22);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button22.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button28_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button28.BackColor != Color.Green)
            {
                ob.Add(28, "28,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button28.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button28.BackColor == Color.Green)
            {
                ob.Remove(28);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button28.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button29_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button29.BackColor != Color.Green)
            {
                ob.Add(29, "29,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button29.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button29.BackColor == Color.Green)
            {
                ob.Remove(29);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button29.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button30_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button30.BackColor != Color.Green)
            {
                ob.Add(30, "30,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button30.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button30.BackColor == Color.Green)
            {
                ob.Remove(30);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button30.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button27_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button27.BackColor != Color.Green)
            {
                ob.Add(27, "27,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button27.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button20.BackColor == Color.Green)
            {
                ob.Remove(27);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button27.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button25_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button25.BackColor != Color.Green)
            {
                ob.Add(25, "25,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button25.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button25.BackColor == Color.Green)
            {
                ob.Remove(25);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button25.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button26_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button26.BackColor != Color.Green)
            {
                ob.Add(26, "26,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button26.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button26.BackColor == Color.Green)
            {
                ob.Remove(26);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button26.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void Button17_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (Button17.BackColor != Color.Green)
            {
                ob.Add(17, "17,");
                Label4.Text = "";
                count = count + 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button17.BackColor = Color.Green;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
            else if (Button17.BackColor == Color.Green)
            {
                ob.Remove(17);
                Label4.Text = "";
                count = count - 1;
                total = fare * count;
                Label6.Text = Convert.ToString(total);
                Button17.BackColor = Color.LightGray;
                foreach (KeyValuePair<int, string> ele1 in ob)
                {
                    Label4.Text = Label4.Text + Convert.ToString(ele1.Value);
                }
            }
        }

        protected void conformticket_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedItem.Text == "Pickup Point" && DropDownList2.SelectedItem.Text == "Drop Point")
            {
                Label15.ForeColor = Color.DarkRed;
                Label15.Text = "Please Select Pickup and Drop point";

            }
            else if (count == 0)
            {
                Label15.ForeColor = Color.DarkRed;
                Label15.Text = "Please Select Seat";
            }
            else if (count > 5)
            {
                Label15.ForeColor = Color.DarkRed;
                Label15.Text = "Please Select only 5 Seat";
            }
            else
            {
                Setbookdeteils();
                Panel4.Visible = true;
            }
        }
        public void Setbookdeteils()
        {
            Label18.Text = Label9.Text + " " + Label10.Text;
            Label17.Text = Label11.Text + " " + Label12.Text;
            Label19.Text = Label7.Text;
            Label20.Text = DropDownList1.SelectedItem.Text;
            Label21.Text = DropDownList2.SelectedItem.Text;
            Label29.Text = Label4.Text;
            Label24.Text = Label6.Text;
            Label30.Text = TextBox5.Text;
        }
        public void getusermailid()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select email from userinfo where uid='" + userid + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    usermail = dr[0].ToString();
                }
                con.Close();
            }
        }
        string usermail = "";
        string pnr = "";
        protected void Button31_Click(object sender, EventArgs e)
        {
            getusermailid();
            DateTime dt = new DateTime();
            Random r = new Random();
            pnr = Convert.ToString(r.Next(000000, 999999));
            //booking ticket 
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("spbookticket", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userid", userid);
                cmd.Parameters.AddWithValue("@pname", TextBox1.Text);
                cmd.Parameters.AddWithValue("@rstart", Label18.Text);
                cmd.Parameters.AddWithValue("@rend", Label17.Text);
                cmd.Parameters.AddWithValue("@numseat", Label29.Text);
                cmd.Parameters.AddWithValue("@total", Label24.Text);
                cmd.Parameters.AddWithValue("@tid", Label19.Text);
                cmd.Parameters.AddWithValue("@busno", busno.ToString());
                cmd.Parameters.AddWithValue("@mno", TextBox2.Text);
                cmd.Parameters.AddWithValue("@jdate", Label30.Text);
                cmd.Parameters.AddWithValue("@bdate", DateTime.Now.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@pnr", pnr.ToString());
                cmd.Parameters.AddWithValue("@busid", aid);
                cmd.Parameters.AddWithValue("@totalseat", ob.Count);
                cmd.Parameters.AddWithValue("@totalprice ", Label24.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "alert", "alert('Your ticket booked...!');", true);
            }
             seatbook();
            sendemail();
            callmethodseat();
           // exportpdf();
        }
        public void sendemail()
        {
            //ticket booking mail
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(usermail);
            mail.From = new MailAddress("Arbooking321@gmail.com", "AR-Booking", System.Text.Encoding.UTF8);
            mail.Subject = "AR-Booking Tikcet conformation mail";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Dear, " + TextBox1.Text + " <br /><br /> Thank bor  booking ticket with  AR-Booking <br /> Your Booking Deteils <br/> PNR:" + pnr + "<br /> Name:" + TextBox1.Text + " <br /> Seats: " + Label29.Text + " <br /> Pick-UP Point:" + DropDownList1.SelectedItem.Text + " <br />Time:" + Label10.Text + "<br /> Total Fare:" + Label24.Text + "<br /> Journey Date:" + Label30.Text + "<br />Driver Mobile NO:" + mno.ToString() + " <br/><br/>ThanKs & Regard <br /> Team A-R Booking ";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("Arbooking321@gmail.com", "Project@123");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }

            }
        }
        public void seatbook()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                foreach (KeyValuePair<int, string> i in ob)
                {
                    string str = " insert into seatavaiable values(" + aid + ",'" + i.Key + "','B','" + Label30.Text + "','" + userid + "')";
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.ExecuteNonQuery();
                }
                con.Close();
            }
        }
        public void nameuser()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select name from userinfo where uid='" + userid + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    username = dr[0].ToString();
                }
                con.Close();
            }
        }
        public void exportpdf()
        {
            if (!Directory.Exists(Server.MapPath("~/Files/")))
            {
                Directory.CreateDirectory(Server.MapPath("~/Files/"));
            }
            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                {
                    HtmlTextWriter htmlWrite = new HtmlTextWriter(hw);
                    System.Web.UI.HtmlControls.HtmlForm frm = new System.Web.UI.HtmlControls.HtmlForm();
                    Panel4.Parent.Controls.Add(frm);
                     

                    frm.Attributes["runat"] = "server";
                    frm.Controls.Add(Panel4);
                   
                    FileStream file = new FileStream(Server.MapPath("~/Files/") + "" + Panel4.ID + ".PDF", FileMode.Create, System.IO.FileAccess.Write);
                    frm.RenderControl(htmlWrite);

                    StringReader sr = new StringReader(htmlWrite.ToString());
                    Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                    HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                    PdfWriter.GetInstance(pdfDoc, file);
                    pdfDoc.Open();
                    htmlparser.Parse(sr);
                    pdfDoc.Close();


                }
            }
        }
    }
}