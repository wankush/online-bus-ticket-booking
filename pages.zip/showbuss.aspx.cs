﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace WebApplication1.userside
{
    public partial class showbuss : System.Web.UI.Page
    {
        static string source;
        static string dist;
        //static string date;
       // DateTime ob = new DateTime();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            source = Request.QueryString["source"];
            dist = Request.QueryString["dist"];
           // TextBox1.Text = DateTime.Now.ToString("yyyy-MM-dd");
            BindRepeator();
        }
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            source = DropDownList1.SelectedItem.Text;
            dist = DropDownList2.SelectedItem.Text;
            string str = "select * from agencyreg where rstart='" + source + "' AND rend='" + dist + "'";
            string CS = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(str, con);
                Repeater1.DataSource = cmd.ExecuteReader();
                Repeater1.DataBind();
            }
        }
        private void BindRepeator()
        {
            //string str = "select * from agencyreg";
           string str = "select * from agencyreg where rstart='" + source + "' AND rend='" + dist + "'";
            string CS = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(str, con);
                Repeater1.DataSource = cmd.ExecuteReader();
                Repeater1.DataBind();
            }
        }
        protected void getvalue_Click(object sender, EventArgs e)
        {
            //Find the button control
            var btn = (Button)sender;
            //Get the repeater selected row
            var item = (RepeaterItem)btn.NamingContainer;
            //FInd the control from row
            var IdValue = ((Label)item.FindControl("Label7")).Text;
            // Your code to update the value in datbaase

            Response.Redirect("~/bookticket.aspx?aid=" + IdValue + "&date=" +   TextBox1.Text);
        }

    }
}