﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace WebApplication1
{
    public partial class home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            getsourcedist();
            getsourcedist2(); 
            
        }
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;

        protected void Searchbus_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/showbuss.aspx?source=" + DropDownList1.SelectedItem.Text + "&dist=" +DropDownList2.SelectedItem.Text );
        }
        public void getsourcedist()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select DISTINCT(rstart)  from agencyreg ";
                SqlCommand cmd = new SqlCommand(str,con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);  // fill dataset  
                DropDownList1.DataTextField = ds.Tables[0].Columns["rstart"].ToString(); // text field name of table dispalyed in dropdown       
                DropDownList1.DataValueField = ds.Tables[0].Columns["rstart"].ToString();
                
                // to retrive specific  textfield name   
                DropDownList1.DataSource = ds.Tables[0];      //assigning datasource to the dropdownlist  
                DropDownList1.DataBind();  //binding dropdownlist  
                 con.Close();
            }
        }
        public void getsourcedist2()
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                string str = "select DISTINCT(rend)  from agencyreg ";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);  // fill dataset  
                DropDownList2.DataTextField = ds.Tables[0].Columns["rend"].ToString(); // text field name of table dispalyed in dropdown       
                DropDownList2.DataValueField = ds.Tables[0].Columns["rend"].ToString();

                // to retrive specific  textfield name   
                DropDownList2.DataSource = ds.Tables[0];      //assigning datasource to the dropdownlist  
                DropDownList2.DataBind();  //binding dropdownlist  
                con.Close();
            }
        }
    }
}